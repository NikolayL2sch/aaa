#ifndef _INPUT_H
#define _INPUT_H

void file_input(char *filename);

#endif //INPUT_H
