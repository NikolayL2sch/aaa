#ifndef _MENU_H
#define _MENU_H

int menu(void);
void print_menu(void);

#endif //_MENU_H
