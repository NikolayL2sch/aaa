#include "constants.h"
#include "menu.h"

int main(void)
{
    int rc = menu();

    return rc;
}
